#' Liquidity Provision Relative to Usage
#'
#' @param participant character value, Identifying code of the payments system
#'                    participant
#' @param payments dataframe value, payments data
#' @return dataframe structure, liquidity provision of the given participant
#'
#' @details
#'
#' Assumes that the payments data file has the form:
#' ID, date, time, value, from, to
#'
liq_prov_rel_usage <- function(participant, payments) {


  if(!"data.table" %in% class(payments)) {
    setDT(payments)
  }

  participants <- unique(payments$from)


  # Participant Level Liquidity Provided and Payments Sent --------------------
  participant_liq_provided <-
    max_liq_prov(participant, payments, T)

  participant_payments_sent <-
    payments[from == participant, .(par_total_payments = sum(value, na.rm = T)), by = .(date)]

  #----------------------------------------------------------------------------

  # Aggregate Level Liquidity Provided and Payments Sent ----------------------

  total_liquidity_provided <-
    lapply(participants,
           function(x)
             max_liq_prov(x, payments, debit = T))

  total_liquidity_provided <-
    do.call("rbind", total_liquidity_provided)

  total_liquidity_provided <-
    total_liquidity_provided[, .(sys_total_liquidity = sum(max_net_pos)),
                             keyby = .(date)]

  total_payments_sent <- payments[, .(sys_total_payments = sum(value)),
                                  keyby = .(date)]

  #----------------------------------------------------------------------------

  setkey(participant_liq_provided, date)
  setkey(total_liquidity_provided, date)
  setkey(participant_payments_sent, date)
  setkey(total_payments_sent, date)

  liq_prov_rel_usage <-
    merge(participant_liq_provided, total_liquidity_provided, all.x = TRUE)

  liq_prov_rel_usage <-
    merge(liq_prov_rel_usage, participant_payments_sent, all.x = TRUE)

  liq_prov_rel_usage <-
    merge(liq_prov_rel_usage, total_payments_sent, all.x = TRUE)

  liq_prov_rel_usage[is.na(liq_prov_rel_usage)] <- 0

  liq_prov_rel_usage[, liq_prov := (max_net_pos / sys_total_liquidity) -
                       (par_total_payments / sys_total_payments)]

  liq_prov_rel_usage[, c("participant", "max_net_pos", "sys_total_liquidity",
                         "par_total_payments", "sys_total_payments") := NULL]

  return(liq_prov_rel_usage)

}
