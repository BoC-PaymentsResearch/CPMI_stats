# Liquidity Efficiency Measures and Drivers

To install the package run the following command in R.

```
install.packages("CPMIstats_0.1.0.tar.gz", repos = NULL)
```
The CPMI_calls.R is an example file with a list of all the functions in the package. For more information on the functions
type ?function_name.
