weighting <- function(t, T_max, t0) {
  return((T_max - t) / (T_max - t0))
}
