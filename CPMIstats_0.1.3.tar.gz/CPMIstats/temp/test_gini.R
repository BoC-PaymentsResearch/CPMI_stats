library(hms)
library(data.table)
library(parallel)


t1 <- fread("/appdata/paysys/protected/boc_ext08_t1_1804.txt")
t2 <- fread("/appdata/paysys/protected/boc_ext08_t2_1804.txt")

col_names <- c("ID", "date", "cycle", "send_time", "settle_time", "value", "from",
               "to", "sdf")


colnames(t1) <- col_names
colnames(t2) <- col_names

t1[, c("cycle", "sdf", "settle_time") := NULL]
t2[, c("cycle", "sdf", "settle_time") := NULL]


setnames(t1, "send_time", "time")
setnames(t2, "send_time", "time")

t1[, time := as.hms(time)]
t2[, time := as.hms(time)]

t1 <- t1[time >= as.hms('06:00:00') & time <= as.hms('18:30:00')]
t2 <- t2[time >= as.hms('06:00:00') & time <= as.hms('18:30:00')]

setkey(t1, date)
setkey(t2, date)

payments_all <- rbind(t1, t2)

gini1 <- gini_coefficient(payments_all)
gini2 <- gini_coefficient2(payments_all)

avg_timing <- avg_payment_timing(payments_all)
