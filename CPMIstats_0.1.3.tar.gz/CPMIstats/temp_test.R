
create_nets_old <- function(participant, payments, debit = T) {

  if(!"data.table" %in% class(payments)) {
    setDT(payments)
  }

  payments_out <-
    payments[from == participant,
             .(payments_out = sum(value)),
             keyby = .(date, time)]

  payments_in <-
    payments[to == participant,
             .(payments_in = sum(value)),
             keyby = .(date, time)]

  setkey(payments_out, date, time)
  setkey(payments_in, date, time)

  net_payments <- merge(payments_out, payments_in, all = TRUE)

  # an NA value at t means no payment was sent at t
  net_payments[is.na(net_payments)] <- 0

  if(debit) {
    net_payments[, net := payments_out - payments_in]
  }
  else {
    net_payments[, net := payments_in - payments_out]
  }

  net_payments <-
    net_payments[, .(net =  cumsum(net)), by = .(date)]


  net_payments <-
    net_payments[, .(max_net_pos = max(net, 0) / 1.0e+09), by = .(date)]

  net_payments[, participant := participant]

  setcolorder(net_payments, c("date", "participant", "max_net_pos"))

  return(net_payments)
}

create_nets_new <- function(participant, payments, debit = T) {

  if(!"data.table" %in% class(payments)) {
    setDT(payments)
  }

  if(debit) {

    payments_out <-
      payments[from == participant, .(FI = sum(value)), keyby = .(date, time)]

    payments_in <-
      payments[to == participant, .(FI = -sum(value)), keyby = .(date, time)]

  } else {

    payments_out <-
      payments[from == participant, .(FI = -sum(value)), keyby = .(date, time)]

    payments_in <-
      payments[to == participant, .(FI = sum(value)), keyby = .(date, time)]

  }

  net_payments <- rbind(payments_out, payments_in)

  setorder(net_payments, date, time)

  net_payments <-
    net_payments[, .(net =  cumsum(FI)), by = .(date)]


  net_payments <-
    net_payments[, .(max_net_pos = max(net, 0) / 1.0e+09), by = .(date)]

  net_payments[, participant := participant]

  setcolorder(net_payments, c("date", "participant", "max_net_pos"))

  return(net_payments)
}
